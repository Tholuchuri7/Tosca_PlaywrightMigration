# Tosca → Playwright Converter V9.2

V9.2 preserves the V9.1 functionality and adds a BusinessType-aware rule for controls that appear in the same JSON execution sequence as a Tosca Table. The module BusinessType of each resolved attribute/control is now respected instead of treating the whole sequence as table content.

## V9.2 additions

- **ControlGroup**: treated as a radio-button group. When the JSON contains a selected value such as `Options -> Ultimate`, the converter first resolves the matching radio child from the already-resolved Tosca module and uses that child's technical ID/class when available; otherwise it falls back to a semantic Playwright radio locator. When the HTML radio is inside the table, the locator remains table-scoped.
- **Link**: when `BusinessType = Link`, the control keeps Link semantics even while table context is active and is generated using Playwright link role/name (or the existing technical/text fallback).
- **Table context**: a surrounding `Table` module no longer causes resolved `ControlGroup` or `Link` controls to be treated as table cells. Normal table row/column verification and existing table controls continue to use the existing logic.

Existing parsing, module resolution/fingerprint matching, dropdown/SELECT handling, table verification, checkbox/radio handling, duplicate control handling, TypeScript/Python generation, and UI are preserved.
